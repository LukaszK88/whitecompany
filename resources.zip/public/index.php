<?php
/**
 * Created by PhpStorm.
 * User: Lukasz
 * Date: 22/11/2016
 * Time: 09:42
 */

require __DIR__ .'/../bootstrap/app.php';

$app->run();